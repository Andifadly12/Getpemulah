import 'package:get/get.dart';

class LoginController extends GetxController {
  RxBool isHidden = true.obs;
  RxBool isLoading = false.obs;
}
